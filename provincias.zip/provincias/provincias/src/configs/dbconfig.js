const config = {
    host : "localhost",
    database : "Provinces",
    user : "postgres",
    password : "root",
    port : 5432
}

export default config;