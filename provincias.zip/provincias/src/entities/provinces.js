class Province{
    id;
    name;
    full_name;
    latitude;
    display_order;
}

export default Province;

