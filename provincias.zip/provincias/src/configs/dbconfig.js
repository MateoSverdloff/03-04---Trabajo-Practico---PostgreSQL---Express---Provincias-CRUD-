const config = {
    host : "localhost",
    database : "Provincias",
    user : "postgres",
    password : "root",
    port : 5432
}

export default config;